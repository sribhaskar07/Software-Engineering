<?php
session_start();
include 'db_connect.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Appointments - CHMS</title>
    <link rel="stylesheet" type="text/css" href="../css/student_dashboard.css">
    <style>
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        h2 {
            margin-bottom: 15px;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            border-radius: 6px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px 15px;
            border: 1px solid #ccc;
            text-align: left;
            font-size: 14px;
        }
        th {
            background-color: #007ACC;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Health Staff</h2>
        <a href="health_staff_dashboard.php">Dashboard</a>
        <a href="appointments_health.php">View Appointments</a>
        <a href="../logout.php">Logout</a>
    </div>

    <div class="content">
        <h2>Booked Appointments</h2>
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Appointment Date</th>
                    <th>Appointment Time</th>
                    <th>Reason</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM appointments ORDER BY appointment_date, appointment_time";
                $result = $conn->query($query);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['user_id']}</td>
                                <td>{$row['appointment_date']}</td>
                                <td>{$row['appointment_time']}</td>
                                <td>{$row['reason']}</td>
                                <td>{$row['status']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No appointments found.</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
