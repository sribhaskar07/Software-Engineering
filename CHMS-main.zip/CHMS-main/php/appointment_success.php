<!DOCTYPE html>
<html>
<head>
    <title>Appointment Confirmed</title>
</head>
<body>
    <h2>✅ Appointment Booked Successfully!</h2>
    <p>Thank you! Your appointment has been submitted and will be reviewed by the health staff.</p>
    <a href="dashboard_student.php">Back to Dashboard</a>
</body>
</html>
