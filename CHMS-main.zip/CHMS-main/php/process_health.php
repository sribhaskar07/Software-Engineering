<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['user_id'])) {
    echo "Session expired. Please log in.";
    exit();
}

$user_id = $_SESSION['user_id'];
$notes = $_POST['notes'];

$stmt = $conn->prepare("INSERT INTO health_records (user_id, notes) VALUES (?, ?)");
$stmt->bind_param("is", $user_id, $notes);

if ($stmt->execute()) {
    echo "✅ Health record submitted successfully.";
} else {
    echo "❌ Failed to submit record: " . $conn->error;
}
?>
