<?php
session_start();
include 'db_connect.php';

// Optional: You can restrict access here based on role if needed
// if ($_SESSION['user']['role'] !== 'health_staff') {
//     header("Location: ../login.php");
//     exit();
// }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Health Staff Dashboard - CHMS</title>
    <link rel="stylesheet" type="text/css" href="../css/student_dashboard.css">
    <style>
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        h2 {
            margin-bottom: 15px;
            color: #333;
        }
        .section {
            margin-bottom: 40px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            border-radius: 6px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            font-size: 14px;
        }
        th {
            background-color: #007ACC;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Health Staff</h2>
        <a href="#">Dashboard</a>
        <a href="dashboard_health.php">View Health Records</a>
        <a href="appointments_health.php">View Appointments</a>
        <a href="../logout.php">Logout</a>
    </div>

    <div class="content">
        <div class="section">
            <h2>Submitted Health Records</h2>
            <table>
                <tr>
                    <th>Student ID</th>
                    <th>Symptoms</th>
                    <th>Temperature (°C)</th>
                    <th>Notes</th>
                    <th>Submitted At</th>
                </tr>
                <?php
                $query1 = "SELECT * FROM health_records ORDER BY submitted_at DESC";
                $result1 = $conn->query($query1);

                if ($result1->num_rows > 0) {
                    while ($row = $result1->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['user_id']}</td>
                                <td>{$row['symptoms']}</td>
                                <td>{$row['temperature']}</td>
                                <td>{$row['notes']}</td>
                                <td>{$row['submitted_at']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No health records found.</td></tr>";
                }
                ?>
            </table>
        </div>

        <div class="section">
            <h2>Booked Appointments</h2>
            <table>
                <tr>
                    <th>Student ID</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Reason</th>
                    <th>Status</th>
                </tr>
                <?php
                $query2 = "SELECT * FROM appointments ORDER BY appointment_date, appointment_time";
                $result2 = $conn->query($query2);

                if ($result2->num_rows > 0) {
                    while ($row = $result2->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['student_id']}</td>
                                <td>{$row['date']}</td>
                                <td>{$row['time']}</td>
                                <td>{$row['reason']}</td>
                                <td>{$row['status']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No appointments found.</td></tr>";
                }

                $conn->close();
                ?>
            </table>
        </div>
    </div>
</body>
</html>
