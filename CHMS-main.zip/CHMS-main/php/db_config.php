<?php
$host = "localhost";
$user = "root"; // Default XAMPP user
$password = ""; // Leave blank for XAMPP
$dbname = "chms"; // Make sure you create this in phpMyAdmin

$conn = mysqli_connect($host, $user, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
