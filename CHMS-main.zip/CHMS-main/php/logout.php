<?php
session_start();
session_destroy();
header("Location: ../login.html"); // or login.php if you're using PHP for login
exit();
?>
