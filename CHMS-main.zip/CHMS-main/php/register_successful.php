<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration Successful</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .message-box {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            text-align: center;
        }
        .message-box h2 {
            color: green;
        }
        .message-box a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007ACC;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .message-box a:hover {
            background-color: #005f99;
        }
    </style>
</head>
<body>
    <div class="message-box">
        <h2>Registration Successful!</h2>
        <p>You can now log in to your account.</p>
        <a href="../login.html">Login Here</a>
    </div>
</body>
</html>
