<?php
ob_start(); // Start output buffering to prevent header issues
session_start();
include 'db_config.php'; // Your DB config

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Secure SQL query
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Verify hashed password
        if (password_verify($password, $user['password'])) {
            // Set session data
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];

            // Redirect based on user role
            if ($user['role'] === 'student') {
                header("Location: ../student_dashboard.php");
                exit();
            } elseif ($user['role'] === 'staff') {
                header("Location: ../health_staff_dashboard.php");
                exit();
            } elseif ($user['role'] === 'admin_staff') {
                header("Location: ../admin_dashboard.php");
                exit();
            } else {
                echo "<p style='color:red;'>⚠️ Unknown user role: {$user['role']}</p>";
            }
        } else {
            echo "<p style='color:red;'>❌ Invalid password. Please try again.</p>";
        }
    } else {
        echo "<p style='color:red;'>❌ No user found with that email.</p>";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "<p style='color:red;'>Invalid request method.</p>";
}
ob_end_flush(); // Flush the output buffer
?>
