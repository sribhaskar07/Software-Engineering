<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user']['role']) || $_SESSION['user']['role'] !== 'health_staff') {
    echo "<p style='color:red;'>Unauthorized access.</p>";
    exit();
}

$result = $conn->query("SELECT a.id, u.name as student_name, a.appointment_date, a.appointment_time, a.reason, a.status
                        FROM appointments a
                        JOIN users u ON a.student_id = u.id
                        ORDER BY a.appointment_date ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Appointments - Health Staff</title>
    <link rel="stylesheet" type="text/css" href="../css/student_dashboard.css">
    <style>
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            background: #f9f9f9;
            box-shadow: 0 0 10px #ccc;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007ACC;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        h2 {
            color: #333;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Health Staff</h2>
        <a href="../dashboard_health.html">Dashboard</a>
        <a href="view_appointments.php">View Appointments</a>
        <a href="#">Notifications</a>
        <a href="../logout.php">Logout</a>
    </div>

    <div class="content">
        <h2>Booked Appointments</h2>
        <table>
            <tr>
                <th>Student</th>
                <th>Date</th>
                <th>Time</th>
                <th>Reason</th>
                <th>Status</th>
            </tr>
            <?php while($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= htmlspecialchars($row['student_name']) ?></td>
                    <td><?= $row['appointment_date'] ?></td>
                    <td><?= $row['appointment_time'] ?></td>
                    <td><?= htmlspecialchars($row['reason']) ?></td>
                    <td><?= $row['status'] ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
