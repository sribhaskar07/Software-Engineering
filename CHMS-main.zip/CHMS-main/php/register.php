<?php
$conn = new mysqli("localhost", "root", "", "chms");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect form data safely
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? 'student'; // Default to student if none selected

// Validate role
$allowed_roles = ['student', 'health_staff', 'admin'];
if (!in_array($role, $allowed_roles)) {
    die("❌ Invalid role selected.");
}

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Prepare SQL query to prevent SQL injection
$stmt = $conn->prepare("INSERT INTO users (email, password, role) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $email, $hashed_password, $role);

if ($stmt->execute()) {
    // Redirect after successful registration
    header("Location: php/register_successful.php");
    exit();
} else {
    if ($conn->errno == 1062) {
        echo "⚠️ This email is already registered. Please <a href='../register.html'>try again</a>.";
    } else {
        echo "❌ Registration failed: " . $conn->error;
    }
}

$stmt->close();
$conn->close();
?>
